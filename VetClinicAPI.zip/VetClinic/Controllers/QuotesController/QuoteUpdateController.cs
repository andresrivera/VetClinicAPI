using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Para usar los modelos en los controladores
using VetClinic.Models;
using Microsoft.AspNetCore.Mvc;
//Para hacer funcionales los servicios
using VetClinic.Services;

namespace VetClinic.Controllers.QuotesControllers
{
    public class QuoteUpdateController: ControllerBase
    {
        private readonly IQuoteRepository _quoteRepository;

        public QuoteUpdateController(IQuoteRepository quoteRepository)
        {
            _quoteRepository = quoteRepository;
        }
    
        [HttpPut]
        [Route("api/quotes/{id}")]
        public async Task<IActionResult> PutQuote(int id, Quote quote)
        {
            if (id != quote.Id)
            {
                return BadRequest();
            }
            try{
            await _quoteRepository.UpdateAsync(quote);
            return NoContent();
            }
            catch (Exception)
            {
                return StatusCode(500,"Fail");
            }
        }
    }
}