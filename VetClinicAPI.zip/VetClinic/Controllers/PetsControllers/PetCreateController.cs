using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
// Usar los modelos en los controladores
using VetClinic.Models;
using Microsoft.AspNetCore.Mvc;
// Para hacer funcionales los servicios
using VetClinic.Services;

namespace VetClinic.Controllers.PetsControllers
{
    public class PetCreateController: ControllerBase
    {
        private readonly IPetRepository _petRepository;

        public PetCreateController(IPetRepository petRepository)
        {
            _petRepository = petRepository;
        }
        
        [HttpPost]
        [Route("api/pets")]
        public async Task<ActionResult<Pet>> PostPet(Pet pet)
        {
            try
            {
                // Lógica para agregar la mascota a la base de datos
                await _petRepository.AddAsync(pet);
                return Ok(new { message = "New pet created 🥰" });
            }
            catch (Exception)
            {
                return StatusCode(500, "Enter specie (Dog, Horse, Cat, Bird, Snake) and race in field (Anerican, Brithish, None)");
            }
        } 
        
    }
}