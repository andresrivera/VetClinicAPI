using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Para usar los modelos en los controladores
using VetClinic.Models;
using Microsoft.AspNetCore.Mvc;
//Para hacer funcionales los servicios
using VetClinic.Services;

namespace VetClinic.Controllers.PetsControllers
{
    public class PetUpdateController: ControllerBase
    {
        private readonly IPetRepository _petRepository;

        public PetUpdateController(IPetRepository petRepository)
        {
            _petRepository = petRepository;
        }

        [HttpPut]
        [Route("api/pets/{id}")]
        public async Task<IActionResult> PutPet(int id, Pet pet)
        {
            if (id != pet.Id)
            {
                return BadRequest();
            }
            try{
            await _petRepository.UpdateAsync(pet);
            return NoContent();
            }
            catch (Exception)
            {
                return StatusCode(500,"Please enter the species field (Dog, Cat Bird) and the breed field (Husky, Pitbull or Yorkie)");
            }
        }
        
    }
}