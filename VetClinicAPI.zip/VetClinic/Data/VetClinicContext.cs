using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Para activar el uso de los modelos
using VetClinic.Models;
//Para poder conectar la base de datos
using Microsoft.EntityFrameworkCore;

namespace VetClinic.Data
{
    public class VetClinicContext : DbContext
    {
        //Contruimos la conexión
        public VetClinicContext (DbContextOptions<VetClinicContext> options): base(options)
        {}

        //Registramos los modelos (Tuve que cambiar el nombre del modelo Vet por Vete porque llame el proyecto Vet y no podía tener el nombre del namespace)
        public DbSet<Vete> Vets { get; set; }
        public DbSet<Owner> Owners { get; set; }
        public DbSet<Pet> Pets { get; set; }
        public DbSet<Quote> Quotes { get; set; }

    }
}