using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VetClinic.Models
{
    public class Email
    {
        public From From { get; set; }
        public To[] To { get; set; }
        public string Subject { get; set; }
        public string Text { get; set; }
        public string Html { get; set; }
    }
    public class From
    {
        public string Email { get; set; }
    }
    public class To
    {
        public string Email { get; set; }
    }

}