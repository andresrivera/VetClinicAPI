using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
//Para activar el JsonIgnore
using System.Text.Json.Serialization;
//Para la anotación Key y aclarar que es la llave primaria
using System.ComponentModel.DataAnnotations;


namespace VetClinic.Models
{
    public class Quote
    {
        [Key]
        public int Id { get; set; }
        public required DateTime Date { get; set; }
        public int PetId { get; set; }
        [JsonIgnore]
        public Pet? Pet { get; set; }
        public int VetId { get; set; }
        [JsonIgnore]
        public Vete? Vet { get; set; }
        public required string Description { get; set; }
    }
}