using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//Para activar el JsonIgnore
using System.Text.Json.Serialization;
//Para la anotación Key y aclarar que es la llave primaria
using System.ComponentModel.DataAnnotations;

namespace VetClinic.Models
{
    public class Owner
    {
        [Key]
        public int Id { get; set; }
        public  string? Names { get; set; }
        public  string? LastNames { get; set; }
        public  string? Email { get; set; }
        public  string? Address { get; set; }
        public  string? Phone { get; set; }
        [JsonIgnore]
        public List<Pet>? Pets { get; set; }
    }
}