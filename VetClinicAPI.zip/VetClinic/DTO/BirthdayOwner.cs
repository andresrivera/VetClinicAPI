using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VetClinic.DTO
{
    public class BirthdayOwner
    {
        public string? NamePet { get; set; }
        public string? NameOwner { get; set; }
        public string? EmailOwner { get; set; }
        public string? PhoneOwner { get; set; }
    }
}