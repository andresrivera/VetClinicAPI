using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VetClinic.DTO
{
    public class OwnerPet
    {
        public string? NameOwner { get; set; }
        public string? EmailOwner { get; set; }
        public string? NamePet { get; set; }
        public string? SpeciePet { get; set; }
        public string? RacePet { get; set; }

    }
}